%%  CREATING USER-DEFINED FUNCTIONS
% Mfanafuthi Khoza - B. Sc Eng. Electrical (UCT)
%
%%
% * A simple function in mathemathics, $f(x)$, associates a unique number to
% each value of $x$
%
% * This function is usually expressed as $y = f(x)$ where $f(x)$ is usually
% a methematical expression like $x^2+2$ , $cos(x)$
%
% * When a function is simple and its output is only needed once, it can be
% typed as part of the program
% 
% * If a function needs to be evaluated many times for different input
% values, it is convinient to create a "user-defined" function
%
% * Once a user-defined function is created and saved, it can be used just
% like the built-in functions
%
% * *_A user-defined function is a MATLAB program that is created by the
% user, saved as a function file and then used like a built-in function._*
%
% * The main feature of a function is that it has an input and an ouput
%
% * A function can take input like numbers, arrays, strings e.t.c.:
%%
a = imread('basic_function.png');
imshow(a), title('Basic function')
%%
% *A user-defined function that calculates the maximum height the ball
% reaches when thrown upwards with a certain velocity:*
%%
% * For a given velocity $v_o$, the maximum height becomes $h_m = (v_o^2)/(2g)$
%%
% * In this case, the input is the veolocity (a number) and the output is
% maximum height (a number), for 15 m/s initial velocity:

g = 9.81;
v = 15;
h_max = (v^2)/(2*g);
fprintf('The maximum height is %.2f\n',h_max)

%%
height = max_height(15);
fprintf('The maximum height is %.2f\n',height)
%%
%%
function h = max_height(v)

g = 9.81;
h = (v^2)/(2*g);
end
%%
%% 7.1 CREATING A FUNCTION FILE
%
% * Function files can be created and edited like script files in the
% Editor/Debugger Window
%
% * In fact, a function file is just a script file that has a defined
% function in it
%
% * The function file can be created by either using a pre-typed function
% file: In the Command Window, in the *File* menu, select *New*, and then
% select *Function*
%
% * Or by just opening an empty script-file, typing the  function
% defininition line and saving the file

%% 7.2 STRUCTURE OF A FUNCTION FILE
% |max_height| function file
%
% *7.2.1 Function Definition Line*
%
% The first executable line in a function file *MUST* be the funtion
% definition line. Otherwise the file is considered as a script file. The
% function line has the following characteristics:
%
% * It defines the file as a function file
% * Defines the name of the function
% * Defines the number and order of the input and output arguments
%
% The form of the function definition line is:
%
%   function [output1, output2,...] = function_name(input1,input2,...)
%
% The word |function| *must* be typed in lowercase letters as the first
% word in the function definition line. On the screen, the word function
% appears in blue
%
% The rules that apply in the variable name apply in the function name,
% THERE SHOULD BE NO SPACES IN THE FUNCTION NAME.
%
% *7.2.2 Input and Output Arguments*
%
% The input and outputs are used to transfer data into and out of the
% function respectively:
%
% * The function can have none or a number of input arguments. The
% expressions within the function file must be constistent with the type of
% inputs that are the function accepts
% * The actual values of input are assigned when the function is used
% (called)
% * The output arguments, which are listed in the square brackets on the
% let side of the assignment operator of the function definition line,
% transfer the output from the function file
% * Function file can have zero, one, or several ouput arguments
% *  If it is more than one, they must be separated using commas
% * A function that has no ouput argument, can for example, generate a plot
% or write data to a file e.t.c.
% * Strings can be passed as input variables using the single quotation
% marks
%%
% *Analyze the following function definition lines:*
%
%   function [mpay,tpay] = loan(amount,rate,years)
%   funtion [A] = RectArea(a,b)
%   function A = RectArea(a,b)
%   function [V,S] = SphereVolArea(r)
%   function trajectory(v,h,g)

%%
% *7.2.3. The H1 Line and Help Text Lines*
%
% These lines of code are typed as comments
%
% They are there to help a user of the function to understand how it
% operates
%%
%   help max_height
%   help loan
%%
% *7.2.3. Function Body*
%
% * The function body contains the actual computer program that performs the
% computations
% * The code can use all MATLAB program features
% * For a much cleaner code, end your function file with a |end| command
%
%% 7.3 LOCAL AND GLOBAL VARIABLES
%
% * All the variable in a function are local to that function file
%
% * This means that they can only be used by the function itself and not
% shared with other functions or the workspace of the Command Window
%
% * To make the variable accesible outside the function itself, the
% |global| command can be used:
%
%   global variable_name
%% 7.4 SAVING A FUNCTION FILE
%
% * Function files can be saved the same way that a script file is saved

%% 7.5 USING USER-DEFINED FUNCTIONS
%
% * Ensure that the file is saved in the current folder in-order to be
% able to use it
% * A function can be used by assigning its output to a variable or
% variables as part of a mathematical expression, as an argument in a
% function, or just by typing its name in the Command Window or script file
%
%   [monthly_payment total_payment] = loan(25000,7.5,4)
%
% Once functions are created, they can be called within other functions,
% script-file or the command window
%
% Create a function that converts input value/values from degrees to
% radians, plot this function for $-360$ $\leq$ $x$ $\leq$ $360$ ,  where
% $x$ is in degrees:
%
%     x = [-360:0.001:360];
%     y = sin(degree_to_rad(x,'m'));
%     plot(x,y),grid,xticks([-360:90:360])





    



