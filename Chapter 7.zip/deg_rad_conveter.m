function radians_output = deg_rad_conveter(xx)

radians_output = pi.*xx./180;
end