function trajectory()
global ab
ab = 2;
fprintf('This function ran...\n')


end