breadth = input('Enter the breadth: ');
length = input('Enter the length: ');
area = length*breadth;