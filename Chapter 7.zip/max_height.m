function [h] = max_height(v,units)
% MAXIMUM HEIGHT IN METRES:
%   This function calculates the maximum height for a given initial
%   velocity
%   The gravitational acceleration constant g = 9.81 m/s^2 is used

g = 9.81; % This variable is local to this function

if units == 'kph'
    v = v*1000/3600;
end
    

h = (v.^2)./(2*g); % Assignment of value to output arguments


end% This signifies the end of your function


