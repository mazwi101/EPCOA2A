function [monthly, total] = loan(P,r,n)
% Loan calculates monthly and total payment of loan.
%   Input Arguments:
%   P = loan amount in R
%   r = annual interest rate in percentage
%   n = number of years
%
%   Output Arguments:
%   monthly = monthly payments
%   total = total payments
format bank
ratem = r*0.01/12;
a = 1 + ratem;
b = (a^(n*12)-1)/ratem;


monthly = P*a^(n*12)/(a*b);
total = monthly*n*12;

end