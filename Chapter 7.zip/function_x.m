 % if the user enters the velocity in kph we want to convert that to mps
 % an hour has 3600s
 % a km has 1000 meters
 % 50 km/h
 
 % 50*1000/3600
 max_height(50,'kph')