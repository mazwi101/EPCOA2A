function A = degree_to_rad(values)
% pi = 180 degrees

A = values.*pi/180;

end